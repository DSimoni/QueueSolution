import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-queue',
  templateUrl: './details-queue.component.html',
  styleUrls: ['./details-queue.component.css']
})
export class DetailsQueueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
